module.exports = {
  content: ['./src/**/*.{astro,js,ts}'],
  theme: {
    extend: {},
  },
  plugins: [],
};